this assumes mubi_ratings.csv is in the hdfs path:

> dataset/mubi/mubi_ratings_data.csv

from the previous data ingestion

### TO RUN:

> python go.py