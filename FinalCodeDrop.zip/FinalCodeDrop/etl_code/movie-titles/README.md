this assumes movie_titles.csv is in the hdfs path:

> dataset/assignment-matrix/movie_titles.csv

from the previous data ingestion

### TO RUN:

> python go.py