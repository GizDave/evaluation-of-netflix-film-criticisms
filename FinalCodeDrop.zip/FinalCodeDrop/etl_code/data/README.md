this assumes data.csv is in the hdfs path:

> dataset/assignment-matrix/data.csv

from the previous data ingestion

### TO RUN:

> python go.py