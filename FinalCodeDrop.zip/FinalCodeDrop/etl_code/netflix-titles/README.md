this assumes netflix_titles.csv is in the hdfs path:

> dataset/netflix-shows/netflix_titles.csv

from the previous data ingestion

### TO RUN:

> python go.py