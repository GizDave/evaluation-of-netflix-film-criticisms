# CLEANING

the directories contains a mapreduce program for cleaning the respective dataset


## netflix-titles

netflix_titles.csv

## assignment-matrix

movie-titles and data

## mubi

mubi_lists_data.csv

mubi_movie_data.csv

mubi_ratings_data.csv